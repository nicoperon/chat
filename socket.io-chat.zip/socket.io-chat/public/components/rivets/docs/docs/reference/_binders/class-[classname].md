Adds a class (whatever value is in place of `[classname]`) on the element when the value evaluates to true and removes that class if the value evaluates to false.

```html
<li rv-class-completed="todo.done">{ todo.name }</li>
```
