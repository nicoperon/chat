Disables the element when the value evaluates to true and enables the element when the value evaluates to false.

```html
<button rv-disabled="user.suspended">Upvote</button>
```
