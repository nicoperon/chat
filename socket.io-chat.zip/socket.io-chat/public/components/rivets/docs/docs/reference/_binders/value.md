Sets the element's value when the attribute changes and sets the bound object's value when the input element changes from user input (two-way).

```html
<input rv-value="item.name">
```
