Sets the element's HTML content.

```html
<section rv-html="item.summary"></section>
```
