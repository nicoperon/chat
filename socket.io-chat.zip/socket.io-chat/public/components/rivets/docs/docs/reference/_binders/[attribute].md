Sets the value of an attribute (whatever value is in place of `[attribute]`) on the element.

*If your binding declaration does not match any of the above routines, it will fallback to use this binding.*

```html
<input type="text" rv-placeholder="field.placeholder">
```
