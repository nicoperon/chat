Hides the element when the value evaluates to true and shows the element when the value evaluates to false.

```html
<section rv-hide="feature.disabled"></section>
```
