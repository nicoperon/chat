Inserts and binds the element as well as it's child nodes into the DOM when the value evaluates to true and removes / unbinds the element when the value evaluates to false.

```html
<section rv-if="item.editable"></section>
```
