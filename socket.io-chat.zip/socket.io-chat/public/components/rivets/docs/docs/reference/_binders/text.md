Sets the element's text content.

```html
<h1 rv-text="user.name"></h1>
```

You can also bind text using interpolation.

```html
<p>{ user.name } is { user.age } years old.</p>
```
