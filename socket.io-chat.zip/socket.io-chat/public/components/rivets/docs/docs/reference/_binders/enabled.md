Enables the element when the value evaluates to true and disables the element when the value evaluates to false.

```html
<button rv-enabled="user.canVote">Upvote</button>
```
