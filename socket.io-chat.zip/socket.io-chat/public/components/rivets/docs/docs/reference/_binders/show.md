Shows the element when the value evaluates to true and hides the element when the value evaluates to false.

```html
<button rv-show="user.admin">Remove</button>
```
