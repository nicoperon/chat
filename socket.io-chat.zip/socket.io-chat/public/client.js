/*global io, rivets, utils*/
/*jslint browser: true*/
var socket = io();
//var  emoji  = require ( ' noeud-emoji ' )
var chatroom = "service-message";
var i, j;

/**
 * Liste des messages
 */
var messages = [];

/**
 * Liste des utilisateurs
 */
var user;
var users = [];


/*** DataBinding initial ***/

rivets.bind($('#messages'), { messages : messages });
rivets.bind($('#users'), { users : users });


/*** Gestion des événements ***/

/**
 * Connexion de l'utilisateur
 * Uniquement si le username n'est pas vide et n'existe pas encore
 */
$('#login form').submit(function (e) {
  e.preventDefault();
  var user = {
    //id = socket.id,
    username : $('#login input').val().trim()
  };
  if (user.username.length > 0) { // Si le champ de connexion n'est pas vide
    socket.emit('user-login', user, function (success) {
      if (success) {
        $('body').removeAttr('id'); // Cache formulaire de connexion
        $('#chat input').focus(); // Focus sur le champ du message
          $('#service-message').append($('<li class="login">').html('<span class="info">information</span> Connecté en tant que '+user.username));
        scrollToBottom();
        // On l'empêche de s'afficher lui même
        setTimeout(function () {
          $('#users li.'+user.username).remove();
        }, 5);
      }
      
    });
  }
});

/**
 * Envoi d'un message
 */
$('#chat form').submit(function (e) {
  e.preventDefault();
  var message = {
      id : chatroom,
      role: "admin",
    //frername : user.username,
    text : $('#m').val()
  };
  $('#m').val('');
  if (message.text.trim().length !== 0) { // Gestion message vide
    socket.emit('chat-message', message);
  }
  $('#chat input').focus(); // Focus sur le champ du message
});

/**
 * Réception d'un message
 */
socket.on('chat-message', function (message) {
  message.label = message.username;
  messages.push(message);
  //utils.scrollToBottom();
});

/**
 * Réception d'un message de service
 */
socket.on('service-message', function (message) {
  message.label = 'information';
  messages.push(message);
//utils.scrollToBottom();
});
//
///**
// * Connexion d'un nouvel utilisateur
// */
//socket.on('user-login', function (user) {
//  users.push(user);
//  setTimeout(function () {
//    $('#users li.new').removeClass('new');
//  }, 1000);
//});
//
///**
// * Déconnexion d'un utilisateur
// */
//socket.on('user-logout', function (user) {
//  var userIndex = users.indexOf(user);
//  if (userIndex !== -1) {
//    users.splice(userIndex, 1);
//  }
//});

// Connexion d'un nouvel utilisateur
socket.on('user-login', function (newUser) {
  $('#users').append($('<li class="new '+newUser.username+'">').html('<a onclick="switchChat(\''+newUser.id+'\', \''+newUser.username+'\')"><span class="unread">💬 </span>'+newUser.username + '<span class="typing">typing</span><a/>'));
  setTimeout(function () {
    $('#users li.new').removeClass('new');
  }, 1000);
  $('#chatrooms').append($('<ul class="chatroom new" id="' + newUser.id + '">'));
  setTimeout(function () {
    $('#chat ul.new').removeClass('new');
  }, 1000);
});



// Déconnexion d'un utilisateur
socket.on('user-logout', function (newUser) {
  var selector = '#users li.' + newUser.username;
  $(selector).remove();
});
// Connexion d'un nouvel utilisateur
socket.on('user-login', function (newUser) {
  $('#users').append($('<li class="new '+newUser.username+'">').html('<a onclick="switchChat(\''+newUser.id+'\', \''+newUser.username+'\')"><span class="unread">💬 </span>'+newUser.username + '<span class="typing">typing</span><a/>'));
  setTimeout(function () {
    $('#users li.new').removeClass('new');
  }, 1000);
  $('#chatrooms').append($('<ul class="chatroom new" id="' + newUser.id + '">'));
  setTimeout(function () {
    $('#chat ul.new').removeClass('new');
  }, 1000);
});



// Déconnexion d'un utilisateur
socket.on('user-logout', function (newUser) {
  var selector = '#users li.' + newUser.username;
  $(selector).remove();
});

/**
 * Détection saisie utilisateur
 */
var typingTimer;
var isTyping = false;

$('#m').keypress(function () {
  clearTimeout(typingTimer);
  if (!isTyping) {
    socket.emit('start-typing');
    isTyping = true;
  }
});

$('#m').keyup(function () {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(function () {
    if (isTyping) {
      socket.emit('stop-typing');
      isTyping = false;
    }
  }, 500);
});

/**
 * Gestion saisie des autres utilisateurs
 */
socket.on('update-typing', function (typingUsers) {
  for (i = 0; i < users.length; i++) {
    users[i].typing = false;
  }
  for (i = 0; i < typingUsers.length; i++) {
    for (j = 0; j < users.length; j++) {
      if (typingUsers[i].username === users[j].username) {
        users[j].typing = true;
        break;
      }
    }
  }
});

function scrollToBottom() {
  if ($(window).scrollTop() + $(window).height() + 2 * $('#'+chatroom+' li').last().outerHeight() >= $(document).height()) {
    $('html, body').animate({ scrollTop: $(document).height() }, 0);
  }
}

// Changement d'onglet
function switchChat(id, username) {
  $('#'+chatroom).hide();
  chatroom = id;
  $('#'+chatroom).show();
  $('#users li.'+username+' span.unread').hide();
}